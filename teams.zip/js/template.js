const teamData = [
  {
    number = "25461Z",
    name = "Uncharted",
    region = "Texas",
    worldCompetitorYears = ["2018","2019"]
  },
  {
    number = "7110Z",
    name = "Fired Up!",
    region = "Texas",
    worldCompetitorYears = ["2018"]
  }
  {
    number = "8110R",
    name = "Knights",
    region = "Minnesota",
    worldCompetitorYears = ["2018","2019"]
  }
];

function worldApperances(worldYears){
  return worldYears.length;
}

document.getElementById("app").innerHTML = `hello`
